import asyncio
import pygame
import random
pygame.init()

p=0.5
bird_y=0
score=0
game_play=True
h_score=0
game_font=pygame.font.Font("assets/04B_19.TTF",40)

def score_view():
    if game_play:
        score_f=game_font.render(f"Score: {str(int(score))}",True,(255,255,255))
        score_hcn=score_f.get_rect(center=(200,30))
        screen.blit(score_f,score_hcn)
    else:
        score_f = game_font.render(f"Score:{str(int(score))}", True, (255, 255, 255))
        score_hcn = score_f.get_rect(center=(200, 30))
        screen.blit(score_f, score_hcn)
        h_score_f = game_font.render(f"High Score:{str(int(h_score))}", True, (255, 0, 0))
        h_score_hcn = h_score_f.get_rect(center=(200, 70))
        screen.blit(h_score_f, h_score_hcn)

pygame.display.set_caption("Con chim den")

icon = pygame.image.load("assets/yellowbird-downflap.png")
bg = pygame.image.load("assets/background-night.png")
fl = pygame.image.load("assets/floor.png")
bg=pygame.transform.scale2x(bg)
pygame.display.set_icon(icon)
fl_x=0

screen=pygame.display.set_mode((400,670))
clock=pygame.time.Clock()

bird1 = pygame.image.load("assets/yellowbird-downflap.png")
bird1=pygame.transform.scale2x(bird1)
bird_hcn=bird1.get_rect(center=(100,350))

screenover = pygame.image.load("assets/message.png")
screenover=pygame.transform.scale2x(screenover)
screenover_hcn=screenover.get_rect(center=(200,300))

# Ong nuoc
pipe_img = pygame.image.load("assets/pipe-green.png")
pipe_img = pygame.transform.scale(pipe_img, (70, 400))
pipe_flip = pygame.transform.flip(pipe_img, False, True)

PIPE_GAP = 180
PIPE_SPEED = 3

pipes = []
pipe_timer = 0
PIPE_INTERVAL = 90  # frames

scored_pipes = set()

def spawn_pipe():
    gap_y = random.randint(200, 430)
    pipes.append({"x": 420, "gap_y": gap_y, "scored": False})

def draw_pipes():
    for pipe in pipes:
        top_rect = pipe_flip.get_rect(bottomleft=(pipe["x"], pipe["gap_y"] - PIPE_GAP // 2))
        bot_rect = pipe_img.get_rect(topleft=(pipe["x"], pipe["gap_y"] + PIPE_GAP // 2))
        screen.blit(pipe_flip, top_rect)
        screen.blit(pipe_img, bot_rect)

def check_pipe_collision():
    for pipe in pipes:
        top_rect = pipe_flip.get_rect(bottomleft=(pipe["x"], pipe["gap_y"] - PIPE_GAP // 2))
        bot_rect = pipe_img.get_rect(topleft=(pipe["x"], pipe["gap_y"] + PIPE_GAP // 2))
        if bird_hcn.colliderect(top_rect) or bird_hcn.colliderect(bot_rect):
            return True
    return False

def reset_game():
    global bird_y, score, game_play, fl_x, bird_hcn, pipes, pipe_timer
    bird_y = 0
    score = 0
    game_play = True
    fl_x = 0
    bird_hcn.center = (100, 350)
    pipes = []
    pipe_timer = 0

def check_vc():
    if bird_hcn.bottom >= 550 or bird_hcn.top <= 0:
        return False
    if check_pipe_collision():
        return False
    return True

async def main():
    global bird_y, score, game_play, h_score, fl_x, bird_hcn, pipes, pipe_timer

    running = True
    while running:
        clock.tick(60)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                if game_play:
                    bird_y = -10
                else:
                    reset_game()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if game_play:
                    bird_y = -10
                else:
                    reset_game()

        screen.blit(bg, (0, 0))

        # Ong nuoc
        if game_play:
            pipe_timer += 1
            if pipe_timer >= PIPE_INTERVAL:
                spawn_pipe()
                pipe_timer = 0

            for pipe in pipes:
                pipe["x"] -= PIPE_SPEED
                if not pipe["scored"] and pipe["x"] + 70 < bird_hcn.left:
                    pipe["scored"] = True
                    score += 1

            pipes[:] = [p for p in pipes if p["x"] > -80]

        draw_pipes()

        # San
        fl_x -= 3
        if fl_x <= -335:
            fl_x = 0
        screen.blit(fl, (fl_x, 550))
        screen.blit(fl, (fl_x + 335, 550))

        if game_play:
            screen.blit(bird1, bird_hcn)
            bird_y += p
            bird_hcn.centery += int(bird_y)
            if score > h_score:
                h_score = score
            score_view()
            game_play = check_vc()
        else:
            screen.blit(screenover, screenover_hcn)
            score_view()

        pygame.display.update()
        await asyncio.sleep(0)

asyncio.run(main())